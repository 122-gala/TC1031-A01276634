/*
    Carlos Arturo Gómez Ayala A01711027
    Gala Moctezuma Cervantes A01276634
    Fecha:5/junio/2025
    Tarea:  Act-Integradora-5 Uso de Tablas Hash

 * compilación y ejecución:
 * compilar: g++ -o sorting sorting.cpp -std=c++11 -Wall -Wextra -O2

    Referencias
    geeksforgeeks; https://www.geeksforgeeks.org/hashing-data-structure/
    programiz: https://www.programiz.com/dsa/hash-table
    tutorialspoint: https://www.tutorialspoint.com/data_structures_algorithms/graphs.htm

 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <algorithm>

using namespace std;

// Estructura para almacenar el resumen de una IP
struct IPSummary {
    string ip;
    int salientes = 0;
    int entrantes = 0;
    float relacion = 0.0;
    vector<string> destinos;
    bool ocupado = false; // indica si el espacio en la tabla hash está ocupado
};

// Convierte una dirección IP en un número entero para aplicar función hash
unsigned long ipToInt(const string& ip) {
    unsigned long result = 0;
    stringstream ss(ip);
    string segment;
    while (getline(ss, segment, '.')) {
        result = result * 256 + stoi(segment);
    }
    return result;
}

// Función hash con prueba cuadrática
int hashFunction(const string& ip, int tableSize, int i) {
    unsigned long key = ipToInt(ip);
    return (key + i*i) % tableSize;
}

// Clase que implementa la tabla hash con dirección abierta y prueba cuadrática
class HashTable {
private:
    vector<IPSummary> table;
    int size;
    int colisiones;
public:
    HashTable(int sz) : size(sz), colisiones(0) {
        table.resize(sz);
    }

    // Inserta un resumen de IP en la tabla hash
    void insert(const string& ip, const IPSummary& data) {
        for (int i = 0; i < size; ++i) {
            int index = hashFunction(ip, size, i);
            if (!table[index].ocupado) {
                table[index] = data;
                table[index].ocupado = true;
                return;
            } else {
                ++colisiones;
                if (table[index].ip == ip) {
                    table[index].salientes += data.salientes;
                    table[index].entrantes += data.entrantes;
                    table[index].destinos.insert(table[index].destinos.end(), data.destinos.begin(), data.destinos.end());
                    return;
                }
            }
        }
    }

    // Retorna el número total de colisiones
    int getCollisions() const {
        return colisiones;
    }

    // Obtiene un puntero al resumen de una IP, si existe
    IPSummary* getIPSummary(const string& ip) {
        for (int i = 0; i < size; ++i) {
            int index = hashFunction(ip, size, i);
            if (table[index].ocupado && table[index].ip == ip) {
                return &table[index];
            }
        }
        return nullptr;
    }
};

// Procesa la bitácora, construye la lista de adyacencia y la tabla hash
void procesarBitacora(const string& filename, HashTable& hashTable, unordered_map<string, vector<string>>& adjList) {
    ifstream file(filename);
    int n, m;
    file >> n >> m;
    vector<string> ipList(n);
    unordered_map<string, int> entrantesCount;

    // Leer todas las IPs
    for (int i = 0; i < n; ++i) {
        file >> ipList[i];
    }

    // Leer las incidencias y construir la lista de adyacencia
    string line;
    getline(file, line); // limpiar salto de línea
    for (int i = 0; i < m; ++i) {
        getline(file, line);
        istringstream ss(line);
        string mes, dia, hora, ipOrigen, ipDestino, peso;
        ss >> mes >> dia >> hora >> ipOrigen >> ipDestino >> peso;

        string ipO = ipOrigen.substr(0, ipOrigen.find(':'));
        string ipD = ipDestino.substr(0, ipDestino.find(':'));

        adjList[ipO].push_back(ipD);
        entrantesCount[ipD]++; // contar aristas entrantes
    }

    // Asegurar que todas las IPs estén en la lista de adyacencia
    for (const string& ip : ipList) {
        if (adjList.find(ip) == adjList.end()) {
            adjList[ip] = {}; // incluir aunque no tenga destinos
        }
    }

    // Insertar en tabla hash los resúmenes de cada IP
    for (auto& par : adjList) {
        string ip = par.first;
        IPSummary summary;
        summary.ip = ip;
        summary.salientes = par.second.size();
        summary.entrantes = entrantesCount[ip];
        summary.relacion = summary.entrantes == 0 ? summary.salientes : (float)summary.salientes / summary.entrantes;
        summary.destinos = par.second;
        hashTable.insert(ip, summary);
    }
}

// Solicita una IP al usuario y muestra su resumen y destinos ordenados
void getIPSummary(HashTable& hashTable, unordered_map<string, vector<string>>& adjList) {
    string ip;
    cout << "\nIngresa una IP para ver su resumen: ";
    cin >> ip;
    IPSummary* info = hashTable.getIPSummary(ip);
    if (!info) {
        cout << "IP no encontrada.\n";
        return;
    }
    // Mostrar resumen
    cout << "Resumen de la IP: " << info->ip << endl;
    cout << " - Direcciones accesadas desde esta IP: " << info->salientes << endl;
    cout << " - Direcciones que accedieron a esta IP: " << info->entrantes << endl;
    cout << " - Relacion salientes/entrantes: " << info->relacion << endl;

    // Ordenar y mostrar los destinos en orden descendente
    sort(info->destinos.begin(), info->destinos.end(), greater<string>());
    cout << "Direcciones accesadas desde esta IP (ordenadas):\n";
    for (const string& dest : info->destinos) {
        cout << "   - " << dest << endl;
    }
}

int main() {
    int tableSize = 15013; // tamaño de la tabla hash (primo para reducir colisiones)
    HashTable hashTable(tableSize);
    unordered_map<string, vector<string>> adjList; // lista de adyacencia del grafo

    // Procesar archivo de bitácora y construir estructuras
    procesarBitacora("bitacoraGrafos.txt", hashTable, adjList);

    // Mostrar número total de colisiones
    cout << "\nTotal de colisiones: " << hashTable.getCollisions() << endl;

    // Permitir consulta de IP al usuario
    getIPSummary(hashTable, adjList);

    return 0;
}
