// Carlos Arturo Gómez Ayala – A01711027  
// Gala Moctezuma Cervantes – A01276634  
// Fecha de entrega: 28 de mayo de 2025  
// Actividad Integradora 4 – Grafos y algoritmos fundamentales  
#ifndef GRAFO_H
#define GRAFO_H

#include <string>
#include <vector>
#include <unordered_map>
#include <set>

// Estructura para guardar una conexión saliente de una IP
// Incluye fecha de conexión, IP destino, y peso de conexión
struct Incidencia {
    std::string fecha;
    std::string destino;
    int peso;
};

// Clase que representa un grafo dirigido con pesos, donde cada vértice es una IP
class Grafo {
private:
    std::unordered_map<std::string, std::vector<Incidencia>> adyacencias; // Lista de adyacencia
    std::unordered_map<std::string, int> gradosSalida; // Mapa de grados de salida
    std::unordered_map<std::string, std::string> primerConexion; // Primera fecha por IP

public:
    // Agrega una conexión dirigida entre dos IPs
    // Complejidad: O(1)
    void agregarConexion(const std::string& origen, const Incidencia& inc);

    // Calcula cuántas conexiones tiene cada IP de salida
    // Complejidad: O(n), siendo n el número total de conexiones
    void calcularGradosSalida();

    // Guarda los grados de salida de cada IP en un archivo
    // Complejidad: O(n)
    void guardarGrados(const std::string& nombreArchivo);

    // Obtiene y guarda las 5 IPs con mayor grado de salida usando Heap
    // Complejidad: O(n log k), donde k=5
    void guardarTop5Grados(const std::string& nombreArchivo, std::string& botMaster);

    // Devuelve la primera vez que una IP realizó una conexión
    // Complejidad: O(1)
    std::string obtenerPrimeraConexion(const std::string& ip);

    // Aplica Dijkstra desde la IP origen para encontrar caminos mínimos
    // Complejidad: O((V + E) log V), usando heap
    std::unordered_map<std::string, int> dijkstra(const std::string& origen, std::unordered_map<std::string, std::string>& previo);
};

#endif