#ifndef HEAP_H
#define HEAP_H

#include <vector>
#include <string>
#include <algorithm>

// NodoHeap almacena una IP y su grado de salida
// Se ordena por grado para implementar un MaxHeap
struct NodoHeap {
    std::string ip;
    int grado;

    // Menor que: para casos donde se requiera comparar ascendente
    // Complejidad: O(1)
    bool operator<(const NodoHeap& otro) const {
        return grado < otro.grado;
    }

    // Mayor que: necesario para comparar correctamente dentro de MaxHeap
    // Complejidad: O(1)
    bool operator>(const NodoHeap& otro) const {
        return grado > otro.grado;
    }
};

class MaxHeap {
private:
    std::vector<NodoHeap> datos; // arreglo que guarda el heap como árbol binario implícito

    // Reorganiza hacia arriba
    // Complejidad: O(log n)
    void heapifyUp(int index);

    // Reorganiza hacia abajo
    // Complejidad: O(log n)
    void heapifyDown(int index);

public:
    // Inserta un nuevo nodo
    // Complejidad: O(log n)
    void push(NodoHeap nodo);

    // Devuelve el nodo con mayor grado
    // Complejidad: O(1)
    NodoHeap top();

    // Elimina el nodo con mayor grado
    // Complejidad: O(log n)
    void pop();

    // Verifica si está vacío
    // Complejidad: O(1)
    bool empty();
};

#endif