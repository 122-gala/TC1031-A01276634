#include "Grafo.h"
#include <fstream>
#include <iostream>
#include <queue>
#include <climits>
#include <algorithm>
#include "Heap.h"

// Agrega una conexión saliente de una IP hacia otra
// Si es la primera vez que esa IP se conecta, también guarda la fecha
// Complejidad: O(1) promedio
void Grafo::agregarConexion(const std::string& origen, const Incidencia& inc) {
    adyacencias[origen].push_back(inc);
    if (primerConexion.find(origen) == primerConexion.end() || inc.fecha < primerConexion[origen]) {
        primerConexion[origen] = inc.fecha;
    }
}

// Cuenta cuántas conexiones de salida tiene cada IP
// Complejidad: O(n), donde n es el total de nodos con lista de adyacencia
void Grafo::calcularGradosSalida() {
    for (const auto& par : adyacencias) {
        gradosSalida[par.first] = par.second.size();
    }
}

// Escribe en un archivo los grados de salida de todas las IPs
// Complejidad: O(n), n = número de nodos
void Grafo::guardarGrados(const std::string& nombreArchivo) {
    std::ofstream out(nombreArchivo);
    for (const auto& par : gradosSalida) {
        out << par.first << " " << par.second << "\n";
    }
}

// Guarda las 5 IPs con más conexiones de salida y guarda cuál es el bot master
// Utiliza un MaxHeap para mantener eficiencia
// Complejidad: O(n log k) con k=5, muy eficiente
void Grafo::guardarTop5Grados(const std::string& nombreArchivo, std::string& botMaster) {
    MaxHeap heap;
    for (const auto& par : gradosSalida) {
        heap.push({par.first, par.second});
    }

    std::ofstream out(nombreArchivo);
    for (int i = 0; i < 5 && !heap.empty(); ++i) {
        NodoHeap nodo = heap.top();
        heap.pop();
        if (i == 0) botMaster = nodo.ip; // la de más grado es la sospechosa
        out << nodo.ip << " " << nodo.grado << "\n";
    }
}

// Devuelve la primera vez que una IP se conectó
// Complejidad: O(1) porque accede a un unordered_map
std::string Grafo::obtenerPrimeraConexion(const std::string& ip) {
    return primerConexion[ip];
}

// Aplica Dijkstra desde un nodo origen a todos los demás
// Guarda también la ruta previa a cada nodo
// Complejidad: O((V + E) log V), muy eficiente para grafos dispersos
std::unordered_map<std::string, int> Grafo::dijkstra(const std::string& origen, std::unordered_map<std::string, std::string>& previo) {
    std::unordered_map<std::string, int> distancias;
    std::set<std::string> visitados;

    for (const auto& par : adyacencias)
        distancias[par.first] = INT_MAX;

    distancias[origen] = 0;

    std::priority_queue<
        std::pair<int, std::string>,
        std::vector<std::pair<int, std::string>>,
        std::greater<std::pair<int, std::string>>
    > pq;

    pq.push({0, origen});

    while (!pq.empty()) {
        auto [dist, actual] = pq.top();
        pq.pop();

        if (visitados.count(actual)) continue;
        visitados.insert(actual);

        for (const auto& vecino : adyacencias[actual]) {
            int nuevaDist = dist + vecino.peso;
            if (nuevaDist < distancias[vecino.destino]) {
                distancias[vecino.destino] = nuevaDist;
                previo[vecino.destino] = actual;
                pq.push({nuevaDist, vecino.destino});
            }
        }
    }

    return distancias;
}