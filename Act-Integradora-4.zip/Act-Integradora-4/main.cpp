// Carlos Arturo Gómez Ayala – A01711027  
// Gala Moctezuma Cervantes – A01276634  
// Fecha de entrega: 28 de mayo de 2025  
// Actividad Integradora 4 – Grafos y algoritmos fundamentales  
// Compilación: g++ -std=c++11 main.cpp Grafo.cpp Heap.cpp -o main.exe
// Ejecución: ./main.exe  

/*
Este programa consiste en construir un sistema que analiza registros de conexiones IP usando grafos dirigidos con listas de adyacencia, 
calculando grados de salida, caminos más cortos con Dijkstra y análisis con Binary Heap.

Referencias:
- GeeksforGeeks. (2024). *Graph and Adjacency List Representation*. https://www.geeksforgeeks.org/graph-and-its-representations/
- GeeksforGeeks. (2024). *Binary Heap Data Structure*. https://www.geeksforgeeks.org/binary-heap/
- cppreference. (2024). *std::priority_queue*. https://en.cppreference.com/w/cpp/container/priority_queue
- Stack Overflow. Preguntas relacionadas al manejo de flujos de archivos en C++ y manipulación de listas con punteros.
- Stack Overflow. Manejo de excepciones std::out_of_range para listas y validaciones.
- ChatGPT (OpenAI). Se utilizó como apoyo en estructura de clases, definición de métodos y análisis de algoritmos y determinar y corregir errores.
        Uso de ChatGPT en el desarrollo:
            Se solicitaron varios apoyos a través de prompts como:”
            - “¿Cómo identifico el nodo con mayor grado de salida en un grafo dirigido?”
            - “Ayúdame a implementar Dijkstra desde una IP origen en una lista de adyacencia.”
            - “¿Cómo represento un camino más largo desde un nodo usando predecesores en C++?”
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include "Grafo.h"

//Quita el puerto de una IP con formato IP:puerto
//complejidad O(n) siendo n el largo de la IP
std::string quitarPuerto(const std::string& ipConPuerto) {
    return ipConPuerto.substr(0, ipConPuerto.find(':'));
}

// Une el mes, dia y hora para formar una fecha
// Complejidad: O(1)
std::string obtenerFecha(const std::string& mes, const std::string& dia, const std::string& hora) {
    return mes + " " + dia + " " + hora;
}

int main() {
    std::ifstream file("bitacoraGrafos.txt");
    if (!file.is_open()) {
        std::cerr << "No se pudo abrir bitacoraGrafos.txt\n";
        return 1;
    }

    int n, m;
    file >> n >> m;
    std::string dummy;
    std::getline(file, dummy); // Limpia fin de linea

    std::vector<std::string> ips;
    for (int i = 0; i < n; ++i) {
        std::string ip;
        std::getline(file, ip);
        ips.push_back(ip);
    }

    Grafo grafo;

    for (int i = 0; i < m; ++i) {
        std::string mes, dia, hora, ipO, ipD, pesoStr, razon;
        file >> mes >> dia >> hora >> ipO >> ipD >> pesoStr;
        std::getline(file, razon); // se ignora razon

        Incidencia inc;
        inc.fecha = obtenerFecha(mes, dia, hora);
        inc.destino = quitarPuerto(ipD);
        inc.peso = std::stoi(pesoStr);

        std::string origen = quitarPuerto(ipO);
        grafo.agregarConexion(origen, inc);
    }

    grafo.calcularGradosSalida();
    grafo.guardarGrados("grados_ips.txt");

    std::string botMaster;
    grafo.guardarTop5Grados("mayores_grados_ips.txt", botMaster);

    std::cout << "Bot master: " << botMaster << "\n";
    std::cout << "Primera conexión: " << grafo.obtenerPrimeraConexion(botMaster) << "\n";

    std::unordered_map<std::string, std::string> previo;
    auto distancias = grafo.dijkstra(botMaster, previo);

    std::ofstream distFile("distancia_botmaster.txt");
    std::string ipMasLejana;
    int maxDist = -1;

    for (const auto& [ip, dist] : distancias) {
        distFile << ip << " " << dist << "\n";
        if (dist != INT_MAX && dist > maxDist) {
            maxDist = dist;
            ipMasLejana = ip;
        }
    }

    std::cout << "IP más lejana: " << ipMasLejana << "\n";

    std::ofstream ataque("ataque_botmaster.txt");
    std::string actual = ipMasLejana;
    std::vector<std::string> camino;
    while (actual != botMaster) {
        camino.push_back(actual);
        actual = previo[actual];
    }
    camino.push_back(botMaster);

    std::reverse(camino.begin(), camino.end());
    for (const std::string& ip : camino) {
        ataque << ip << "\n";
    }

    return 0;
}
