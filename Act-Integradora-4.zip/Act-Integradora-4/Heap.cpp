#include "Heap.h"

// Reorganiza el heap hacia arriba (desde el nodo insertado)
// Complejidad: O(log n) porque sube desde la hoja hasta la raíz en el peor caso
void MaxHeap::heapifyUp(int index) {
    while (index > 0) {
        int padre = (index - 1) / 2;
        if (datos[padre] < datos[index]) {
            std::swap(datos[padre], datos[index]);
            index = padre;
        } else break;
    }
}

// Reorganiza el heap hacia abajo (después de un pop)
// Complejidad: O(log n) porque baja hasta una hoja si es necesario
void MaxHeap::heapifyDown(int index) {
    int size = datos.size();
    while (2 * index + 1 < size) {
        int hijoIzq = 2 * index + 1;
        int hijoDer = 2 * index + 2;
        int mayor = hijoIzq;

        if (hijoDer < size && datos[hijoDer] > datos[hijoIzq]) {
            mayor = hijoDer;
        }

        if (datos[mayor] > datos[index]) {
            std::swap(datos[mayor], datos[index]);
            index = mayor;
        } else break;
    }
}

// Inserta un nodo en el heap
// Complejidad: O(log n) por el heapifyUp
void MaxHeap::push(NodoHeap nodo) {
    datos.push_back(nodo);
    heapifyUp(datos.size() - 1);
}

// Devuelve el nodo con mayor prioridad (mayor grado)
// Complejidad: O(1)
NodoHeap MaxHeap::top() {
    return datos.front();
}

// Elimina el nodo más prioritario (mayor grado)
// Complejidad: O(log n) por el heapifyDown
void MaxHeap::pop() {
    std::swap(datos.front(), datos.back());
    datos.pop_back();
    heapifyDown(0);
}

// Verifica si el heap está vacío
// Complejidad: O(1)
bool MaxHeap::empty() {
    return datos.empty();
}
