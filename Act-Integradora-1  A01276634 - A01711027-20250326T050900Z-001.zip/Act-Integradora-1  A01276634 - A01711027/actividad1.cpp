
//Carlos Arturo Gómez Ayala
//Matrícula A01711027
//24-Marzo-2025
// Actividad Integradora 1
//compilarlo con: g++ actividad1.cpp -o main
// EJECUTARLO con: Get-Content test01.txt | .\main.exe
//                 Get-Content test02.txt | .\main.exe
//                 Get-Content test03.txt | .\main.exe
//                 Get-Content test04.txt | .\main.exe
// Fuentes consultadas:https://www.geeksforgeeks.org/recursion/
//                     https://www.geeksforgeeks.org/analysis-algorithms-big-o-analysis/
//                     https://www.geeksforgeeks.org/searching-algorithms/
//                     https://www.geeksforgeeks.org/selection-sort/Links 
//                     https://www.geeksforgeeks.org/bubble-sort
//                     https://www.geeksforgeeks.org/insertion-sort/Links to an external site. 
//                     https://www.geeksforgeeks.org/merge-sort/
//                     Parte del codigo fue desarrollado con apoyo de ChatGPT (OpenAI). El código de las funciones mergeSort, convertirATimestamp y búsqueda, constructor de BitacoraEntry. OpenAI. (2024). ChatGPT [IA conversacional]. Recuperado de: https://chat.openai.com/

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>

//representa linea de la bitacora con fecha, IP y msj
//contiene metodos para comparar y formatear la entrada
class BitacoraEntry {
public:
    std::string month;
    int day, hour, minute, second;
    std::string ip;
    std::string message;
    int monthNumber;

    // constructor por defecto, para inicializar valores vacíos o cero
    BitacoraEntry() : month(""), day(0), hour(0), minute(0), second(0), ip(""), message(""), monthNumber(0) {}

    // Constructor desde valores individuales
    BitacoraEntry(const std::string& m, int d, int h, int min, int s,
                  const std::string& ipInfo, const std::string& msg)
        : month(m), day(d), hour(h), minute(min), second(s),
          ip(ipInfo), message(msg) {
        monthNumber = convertMonthToNumber(month);
    }

    //constructor desde texto, línea completa de la bitácora dividiendo fecha, hora, IP y mensaje.
    BitacoraEntry(const std::string& line) {
        std::istringstream ss(line);
        ss >> month >> day;

        std::string timeStr;
        ss >> timeStr;

        std::replace(timeStr.begin(), timeStr.end(), ':', ' ');
        std::istringstream timeSS(timeStr);
        timeSS >> hour >> minute >> second;

        ss >> ip;
        std::getline(ss, message);
        monthNumber = convertMonthToNumber(month);
    }
//    Devuelve un valor para comparar fechas completas, convirtiendo mes día y hora en un solo número
    long long getSortKey() const {
        return (long long)monthNumber * 10000000000LL +
               (long long)day * 100000000 +
               (long long)hour * 1000000 +
               (long long)minute * 10000 +
               (long long)second * 100;
    }

    bool operator<(const BitacoraEntry& other) const {
        return this->getSortKey() < other.getSortKey();
    }

    std::string toString() const {
        std::ostringstream out;
        out << month << " "
            << std::setfill('0') << std::setw(2) << day << " "
            << std::setw(2) << hour << ":"
            << std::setw(2) << minute << ":"
            << std::setw(2) << second << " "
            << ip << message;
        return out.str();
    }

private:
    int convertMonthToNumber(const std::string& m) {
        static std::map<std::string, int> months = {
            {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4},
            {"May", 5}, {"Jun", 6}, {"Jul", 7}, {"Aug", 8},
            {"Sep", 9}, {"Oct",10}, {"Nov",11}, {"Dec",12}
        };
        auto it = months.find(m);
        return (it != months.end()) ? it->second : 0;
    }
};

//Funciones globales
long long comparaciones = 0;
long long movimientos = 0;
//combina dos subarreglos ordenados dentro del vector original
void merge(std::vector<BitacoraEntry>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    std::vector<BitacoraEntry> L(n1), R(n2);
    for (int i = 0; i < n1; ++i) L[i] = arr[left + i];
    for (int j = 0; j < n2; ++j) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        comparaciones++;
        if (L[i] < R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
        movimientos++;
    }

    while (i < n1) { arr[k++] = L[i++]; movimientos++; }
    while (j < n2) { arr[k++] = R[j++]; movimientos++; }
}
//algoritmo de ordenamiento. Complejidad: O(n log n) en todos los casos
void mergeSort(std::vector<BitacoraEntry>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}
//Convierte una fecha str a un valor entero
long long convertirFechaAKey(const std::string& fechaStr) {
    std::istringstream ss(fechaStr);
    std::string month;
    int day, hour, minute, second;
    std::string timeStr;

    ss >> month >> day >> timeStr;
    std::replace(timeStr.begin(), timeStr.end(), ':', ' ');
    std::istringstream timeSS(timeStr);
    timeSS >> hour >> minute >> second;

    static std::map<std::string, int> meses = {
        {"Jan",1},{"Feb",2},{"Mar",3},{"Apr",4},{"May",5},{"Jun",6},
        {"Jul",7},{"Aug",8},{"Sep",9},{"Oct",10},{"Nov",11},{"Dec",12}
    };

    int mesNum = meses[month];
    return (long long)mesNum * 10000000000LL +
           (long long)day * 100000000 +
           (long long)hour * 1000000 +
           (long long)minute * 10000 +
           (long long)second * 100;
}
//de busqueda binaria en vector de registros ordenados. O(log n). Muy eficiente para búsquedas de fechas
int busquedaBinaria(const std::vector<BitacoraEntry>& registros, long long clave) {
    int izquierda = 0, derecha = registros.size() - 1;
    while (izquierda <= derecha) {
        int mid = izquierda + (derecha - izquierda) / 2;
        long long claveMid = registros[mid].getSortKey();

        if (clave == claveMid) return mid;
        else if (clave < claveMid) derecha = mid - 1;
        else izquierda = mid + 1;
    }
    return -1;
}

time_t convertirATimestamp(const BitacoraEntry& entry) {
    std::tm timeStruct = {};
    timeStruct.tm_year = 2025 - 1900;
    timeStruct.tm_mday = entry.day;
    timeStruct.tm_hour = entry.hour;
    timeStruct.tm_min  = entry.minute;
    timeStruct.tm_sec  = entry.second;

    static std::map<std::string, int> meses = {
        {"Jan",0},{"Feb",1},{"Mar",2},{"Apr",3},{"May",4},{"Jun",5},
        {"Jul",6},{"Aug",7},{"Sep",8},{"Oct",9},{"Nov",10},{"Dec",11}
    };
    timeStruct.tm_mon = meses[entry.month];

    return std::mktime(&timeStruct);
}
//Busca el primer par de registros con D días de diferencia
void buscarParD(const std::vector<BitacoraEntry>& registros, int D,
                std::ofstream& outBusqueda) {
    outBusqueda << "Busqueda del primer par de registros con " << D << " dias de diferencia:\n";
    std::cout << "Busqueda del primer par de registros con " << D << " dias de diferencia:\n";

    int n = registros.size();
    for (int i = 0; i < n; ++i) {
        time_t base = convertirATimestamp(registros[i]);
        for (int j = i + 1; j < n; ++j) {
            time_t cmp = convertirATimestamp(registros[j]);
            double dif = difftime(cmp, base) / (60 * 60 * 24);
            if ((int)dif == D) {
                outBusqueda << "[" << i << "] " << registros[i].toString() << "\n";
                outBusqueda << "[" << j << "] " << registros[j].toString() << "\n";
                std::cout << "[" << i << "] " << registros[i].toString() << "\n";
                std::cout << "[" << j << "] " << registros[j].toString() << "\n";
                return;
            } else if (dif > D) break;
        }
    }
    outBusqueda << "No existe el par de registros\n";
    std::cout << "No existe el par de registros\n";
}
//complejidad O(n) donde n es el # de líneas en el archivo. Realiza vasrios procesos
int main() {
    std::ifstream file("bitacoraData.txt");
    std::vector<BitacoraEntry> registros;

    if (!file.is_open()) {
        std::cerr << "error al abrir bitacoraData.txt\n";
        return 1;
    }

    std::string line;
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        registros.push_back(BitacoraEntry(line));
    }
    file.close();

    mergeSort(registros, 0, registros.size() - 1);
    std::cout << "Merge Sort\n";
    std::cout << comparaciones << "\n";
    std::cout << movimientos << "\n\n";

    std::ofstream outFile("bitacora_ordenada.txt");
    for (const auto& entry : registros)
        outFile << entry.toString() << "\n";
    outFile.close();

    int B;
    std::cin >> B;
    std::cin.ignore();

    std::ofstream outBusqueda("resultados_busqueda.txt");
    int exitosas = 0, fallidas = 0;

    for (int i = 0; i < B; ++i) {
        std::string fecha;
        std::getline(std::cin, fecha);
        long long clave = convertirFechaAKey(fecha);
        int idx = busquedaBinaria(registros, clave);
        if (idx != -1) {
            outBusqueda << "[" << idx << "] " << registros[idx].toString() << "\n";
            exitosas++;
        } else {
            outBusqueda << "Fecha no existe: " << fecha << "\n";
            fallidas++;
        }
    }

    std::cout << B << "\n" << exitosas << "\n" << fallidas << "\n\n";

    int D;
    std::cin >> D;
    buscarParD(registros, D, outBusqueda);
    outBusqueda.close();

    return 0;
}
