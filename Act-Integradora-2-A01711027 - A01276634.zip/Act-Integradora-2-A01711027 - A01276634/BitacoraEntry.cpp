// BitacoraEntry.cpp
// aqui se implementan los metodos de la clase BitacoraEntry
// todos los metodos tienen complejidad O(1) porque son operaciones directas
#include "BitacoraEntry.h"

BitacoraEntry::BitacoraEntry(const std::string &line) {
    std::stringstream ss(line);
    ss >> month >> day >> hour;
    ss.ignore();
    ss >> min;
    ss.ignore();
    ss >> sec >> ip;
    std::getline(ss, message);

    std::tm tm = {};
    std::istringstream ssTime(month + " " + std::to_string(day) + " " + std::to_string(hour) + ":" +
                              std::to_string(min) + ":" + std::to_string(sec));
    ssTime >> std::get_time(&tm, "%b %d %H:%M:%S");
    date = mktime(&tm);
}

bool BitacoraEntry::operator>=(const BitacoraEntry &other) const { return date >= other.date; }
bool BitacoraEntry::operator<=(const BitacoraEntry &other) const { return date <= other.date; }
bool BitacoraEntry::operator>(const BitacoraEntry &other) const { return date > other.date; }
bool BitacoraEntry::operator<(const BitacoraEntry &other) const { return date < other.date; }

std::string BitacoraEntry::toString() const {
    std::ostringstream os;
    os << month << " " << day << " "
       << std::setfill('0') << std::setw(2) << hour << ":"
       << std::setw(2) << min << ":" << std::setw(2) << sec
       << " " << ip << message;
    return os.str();
}
