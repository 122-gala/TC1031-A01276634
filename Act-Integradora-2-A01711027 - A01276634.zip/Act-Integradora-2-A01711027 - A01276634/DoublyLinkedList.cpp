// DoublyLinkedList.cpp
// contiene implementacion de todos los metodos de la lista
// usar merge sort para ordenar eficientemente O(n log n)
// busqueda binaria en la lista convertida a vector O(log n)
// importante: los metodos estan optimizados para trabajar bien con grandes cantidades de datos
#include "DoublyLinkedList.h"

Node::Node(BitacoraEntry data) : data(data), prev(nullptr), next(nullptr) {}

DoublyLinkedList::DoublyLinkedList() : head(nullptr), tail(nullptr), size(0) {}

DoublyLinkedList::~DoublyLinkedList() {
    while(head) {
        Node *tmp = head;
        head = head->next;
        delete tmp;
    }
}

void DoublyLinkedList::insertEnd(const BitacoraEntry &data) {
    Node *node = new Node(data);
    if (!head) head = tail = node;
    else {
        tail->next = node;
        node->prev = tail;
        tail = node;
    }
    size++;
}

Node* DoublyLinkedList::split(Node *head) {
    Node *fast = head, *slow = head;
    while(fast->next && fast->next->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    Node *temp = slow->next;
    slow->next = nullptr;
    return temp;
}

Node* DoublyLinkedList::merge(Node *first, Node *second) {
    if (!first) return second;
    if (!second) return first;
    if (first->data > second->data) {
        first->next = merge(first->next, second);
        first->next->prev = first;
        first->prev = nullptr;
        return first;
    } else {
        second->next = merge(first, second->next);
        second->next->prev = second;
        second->prev = nullptr;
        return second;
    }
}

Node* DoublyLinkedList::mergeSort(Node *node) {
    if (!node || !node->next) return node;
    Node *second = split(node);
    node = mergeSort(node);
    second = mergeSort(second);
    return merge(node, second);
}

void DoublyLinkedList::sort() { head = mergeSort(head); }

int DoublyLinkedList::binarySearch(const BitacoraEntry &target) {
    std::vector<Node*> nodes;
    Node *curr = head;
    while(curr) {
        nodes.push_back(curr);
        curr = curr->next;
    }
    int l = 0, r = nodes.size() - 1;
    while(l <= r) {
        int m = l + (r - l) / 2;
        if(nodes[m]->data.date == target.date) return m;
        if(nodes[m]->data.date < target.date) r = m - 1;
        else l = m + 1;
    }
    return -1;
}

BitacoraEntry DoublyLinkedList::at(int idx) {
    Node *curr = head;
    while(idx--) curr = curr->next;
    return curr->data;
}

int DoublyLinkedList::getSize() { return size; }