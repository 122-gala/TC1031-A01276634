//Carlos Arturo Gómez Ayala
//Matrícula A01711027
//24-Marzo-2025
// Actividad Integradora 1
//compilarlo con: g++ -std=c++17 main.cpp BitacoraEntry.cpp DoublyLinkedList.cpp -o integradora2
// EJECUTARLO con: .\integradora2.exe
// Fuentes consultadas:https://www.geeksforgeeks.org/recursion/
//                     https://www.geeksforgeeks.org/analysis-algorithms-big-o-analysis/
//                     https://www.geeksforgeeks.org/searching-algorithms/
//                     https://www.geeksforgeeks.org/selection-sort/Links 
//                     https://www.geeksforgeeks.org/bubble-sort
//                     https://www.geeksforgeeks.org/insertion-sort/Links to an external site. 
//                     https://www.geeksforgeeks.org/merge-sort/
//                     Parte del codigo fue desarrollado con apoyo de ChatGPT (OpenAI). El código de las funciones mergeSort, convertirATimestamp y búsqueda, constructor de BitacoraEntry. OpenAI. (2024). ChatGPT [IA conversacional]. Recuperado de: https://chat.openai.com/

#include <iostream>
#include <fstream>
#include "DoublyLinkedList.h"
//todos los metodos para manipular archivos tienen try y catch para correcto funcionamiento
int main() {
    DoublyLinkedList lista;

    try {
        std::ifstream input("bitacoraData.txt");
        if (!input.is_open()) throw std::runtime_error("Error al abrir el archivo bitacoraData.txt");

        std::string line;
        while (std::getline(input, line))
            lista.insertEnd(BitacoraEntry(line));// insertar al final O(1)
        input.close();

        lista.sort();// mergesort O(n log n), muy eficiente

        std::ofstream ordenada("bitacora_ordenada.txt");
        if (!ordenada.is_open()) throw std::runtime_error("Error al crear el archivo bitacora_ordenada.txt");
        for (int i = 0; i < lista.getSize(); i++)
            ordenada << lista.at(i).toString() << "\n";
        ordenada.close();

        std::string inicio, fin;
        std::cout << "Introduce fecha inicial (e.g., Jun 01 00:22:36): ";
        getline(std::cin, inicio);
        std::cout << "Introduce fecha final (e.g., Jun 01 00:22:36): ";
        getline(std::cin, fin);

        BitacoraEntry inicioBusqueda(inicio), finBusqueda(fin);
        // busqueda binaria O(log n) muy rapida comparado con busqueda lineal que es O(n)
        int idxInicio = lista.binarySearch(inicioBusqueda);
        int idxFin = lista.binarySearch(finBusqueda);

        if (idxInicio == -1 || idxFin == -1) {
            std::cerr << "Una o ambas fechas no se encontraron en la bitacora.";
            return 1;
        }

        std::ofstream salida("resultado_busqueda.txt");
        if (!salida.is_open()) throw std::runtime_error("Error al crear el archivo resultado_busqueda.txt");

        for (int i = idxInicio; i <= idxFin; i++) { // O(k) donde k es el numero de registros entre idxInicio e idxFin
            std::cout << lista.at(i).toString() << "\n";
            salida << lista.at(i).toString() << "\n";
        }
        salida.close();

    } catch (const std::exception &e) {
        std::cerr << e.what();
        return 1;
    }

    return 0;
}
// Resumen Complejidad:
// - insertEnd: O(1) ya que siempre se inserta directamente al final
// - sort (merge sort): O(n log n),gracias al merge sort que es muy eficiente pa listas grandes
// - binarySearch: O(log n)es muy rapido comparado con busqueda lineal que es O(n)
// - recorrer lista (for): O(n) inevitable por que hay que revisar cada elemento
// esto hace y asegura que el programa sea eficiente incluso con archivos grandes

//Mejoras hechas desde actividad pasada:
//-Clases separadas correctamente en .h y .cpp
//-Manejo correcto de excepciones
//-Algoritmos eficientes (merge sort y busqueda binaria) en vez del cuadratico del pasado