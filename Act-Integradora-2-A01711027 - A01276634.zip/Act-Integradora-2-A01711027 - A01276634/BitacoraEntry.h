// BitacoraEntry.h
// esta clase representa un registro individual de la bitacora
// Complejidad de constructores y comparaciones: O(1)
#ifndef BITACORAENTRY_H
#define BITACORAENTRY_H

#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>

class BitacoraEntry {
public:
    std::string month;
    int day, hour, min, sec;
    std::string ip, message;
    time_t date;

    BitacoraEntry(const std::string &line);
    bool operator>=(const BitacoraEntry &other) const;
    bool operator<=(const BitacoraEntry &other) const;
    bool operator>(const BitacoraEntry &other) const;
    bool operator<(const BitacoraEntry &other) const;
    std::string toString() const;
};

#endif