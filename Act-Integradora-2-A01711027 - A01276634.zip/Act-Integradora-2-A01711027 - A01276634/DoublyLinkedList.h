// DoublyLinkedList.h
// implementacion de una lista doblemente ligada
// metodos principales:
// - insertar al final O(1)
// - ordenar con MergeSort O(n log n)
// - busqueda binaria adaptada O(log n)
// - acceso a un elemento especifico O(n)
#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H
#include "BitacoraEntry.h"
#include <vector>

struct Node {
    BitacoraEntry data;
    Node *prev, *next;
    Node(BitacoraEntry data);
};

class DoublyLinkedList {
private:
    Node *head, *tail;
    int size;
    Node* split(Node *);
    Node* merge(Node *, Node *);
    Node* mergeSort(Node *);

public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    void insertEnd(const BitacoraEntry &data);
    void sort();
    int binarySearch(const BitacoraEntry &target);
    BitacoraEntry at(int idx);
    int getSize();
};

#endif