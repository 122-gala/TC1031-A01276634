// Carlos Arturo Gómez Ayala A01711027
// Gala Moctezuma Cervantes A01276634
// 14-mayo-2025
// Act3 - Estructuras de datos jerárquicas (Heap Sort y Binary Heap)
// Compilar con: g++ -std=c++11 main.cpp -o main.exe
// Ejecutar con: .\main.exe
// Fuentes consultadas (Referencias):
// - GeeksforGeeks. (2024). Heap Sort Algorithm. https://www.geeksforgeeks.org/heap-sort/
// - GeeksforGeeks. (2024). Priority Queue (Binary Heap) Implementation. https://www.geeksforgeeks.org/priority-queue-using-binary-heap/
// - Stack Overflow. (2025). Parsing IP addresses and string manipulation in C++
// - cppreference. (2024). std::priority_queue. https://en.cppreference.com/w/cpp/container/priority_queue
// - ChatGPT (OpenAI). Se utilizó para estructurar y validar la lógica de heaps, heap sort y análisis de errores, ajustes.

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <algorithm>

struct Registro {
    std::string mes, dia, hora, ip, razon;
    std::string soloIP; // Para ordenar sin considerar puerto

    Registro(std::string m, std::string d, std::string h, std::string i, std::string r)
        : mes(m), dia(d), hora(h), ip(i), razon(r) {
        soloIP = ip.substr(0, ip.find(":"));
    }

    std::string toString() const {
        return mes + " " + dia + " " + hora + " " + ip + " " + razon;
    }
};

//comparador por IP (sin puerto)
bool compareIP(const Registro& a, const Registro& b) {
    return a.soloIP < b.soloIP;
}

//Heapify para Heap Sort (O(log n))
void heapify(std::vector<Registro>& v, int n, int i) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;

    if (l < n && compareIP(v[largest], v[l]))
        largest = l;
    if (r < n && compareIP(v[largest], v[r]))
        largest = r;

    if (largest != i) {
        std::swap(v[i], v[largest]);
        heapify(v, n, largest);
    }
}

// Heap Sort (O(n log n) peor caso)
void heapSort(std::vector<Registro>& v) {
    int n = v.size();
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(v, n, i);
    for (int i = n - 1; i >= 0; i--) {
        std::swap(v[0], v[i]);
        heapify(v, i, 0);
    }
}

int main() {
    std::ifstream archivo("bitacoraHeap.txt");
    std::vector<Registro> registros;
    std::string mes, dia, hora, ip, razon;

    // Leer el archivo de entrada
    while (std::getline(archivo, mes, ' ') &&
           std::getline(archivo, dia, ' ') &&
           std::getline(archivo, hora, ' ') &&
           std::getline(archivo, ip, ' ') &&
           std::getline(archivo, razon)) {
        registros.emplace_back(mes, dia, hora, ip, razon);
    }
    archivo.close();

    //Ordenamiento de los registros por IP con Heap Sort
    heapSort(registros);

    // Guardar la bitacora ordenada
    std::ofstream salidaOrdenada("bitacora_ordenada.txt");
    for (const auto& r : registros) {
        salidaOrdenada << r.toString() << std::endl;
    }
    salidaOrdenada.close();

    //Contabilizar a los accesos por IP (O(n))
    std::unordered_map<std::string, int> contador;
    for (const auto& r : registros) {
        contador[r.soloIP]++;
    }

    // Priority Queue (MaxHeap) para contar los accesos (O(n log n))
    using Par = std::pair<int, std::string>; // {accesos, IP}
    std::priority_queue<Par> heap;
    for (const auto& p : contador) {
        heap.push({p.second, p.first});
    }

    // Top 10 IPs con más accesos
    std::ofstream topIPs("ips_con_mayor_acceso.txt");
    std::cout << "Top 10 IPs con más accesos:\n";
    for (int i = 0; i < 10 && !heap.empty(); i++) {
        auto [cnt, ip] = heap.top(); heap.pop();
        std::cout << ip << " - " << cnt << " accesos\n";
        topIPs << ip << " - " << cnt << " accesos\n";
    }
    topIPs.close();

    //Buscar la IP con menor acceso (>=3)
    std::vector<Par> temporal;
    Par menorAcceso = {INT_MAX, ""};
    while (!heap.empty()) {
        Par actual = heap.top(); heap.pop();
        if (actual.first >= 3 && actual.first < menorAcceso.first) {
            menorAcceso = actual;
        }
        temporal.push_back(actual);
    }

    if (menorAcceso.second != "") {
        std::cout << "\nIP con menor acceso (>=3): " << menorAcceso.second
                  << " - " << menorAcceso.first << " accesos\n";
    } else {
        std::cout << "\nNo se encontró IP con al menos 3 accesos.\n";
    }

    return 0;
}
